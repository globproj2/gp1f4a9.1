<?php
	$host="xxxxxxx";# Nom del contenidor amb el servidor MySQL
	$user="xxxxxx";
	$passwd="xxxxxx";
	$bd="xxxxxx";
	$taula="xxxxx";	
?>
